var chinaData = null;

//ajax的JSON请求数据
$.when(
    $.ajax({
        url:"https://view.inews.qq.com/g2/getOnsInfo?name=disease_h5",
        dataType:"jsonp",
        success:function (data) {
            chinaData = JSON.parse(data.data);
            console.log(JSON.parse(data.data));
            console.log(chinaData.lastUpdateTime);
        }
    })
).then(function () {
    title();
    brief();
    map();
})

//设置title
function title(){
    $(".brief .brief_header p").text("更新时间:"+chinaData.lastUpdateTime);
}

//设置总览数据
function brief(){
    var htmlStr = `
            <li class="allConfirm">
                <div class="number">${chinaData.chinaTotal.confirm}</div>
                <div class="item">累计确诊</div>
                <div class="change"><span>昨日</span><b>${chinaData.chinaAdd.confirm}</b></div>
            </li>
            <li class="allHeal">
                <div class="number">${chinaData.chinaTotal.heal}</div>
                <div class="item">累积治愈</div>
                <div class="change"><span>昨日</span><b>${chinaData.chinaAdd.heal}</b></div>
            </li>
            <li class="allDead">
                <div class="number">${chinaData.chinaTotal.dead}</div>
                <div class="item">累积死亡</div>
                <div class="change"><span>昨日</span><b>${chinaData.chinaAdd.dead}</b></div>
            </li>
            <li class="nowConfirm">
                <div class="number">${chinaData.chinaTotal.nowConfirm}</div>
                <div class="item">现有确诊</div>
                <div class="change"><span>昨日</span><b>${chinaData.chinaAdd.nowConfirm}</b></div>
            </li>
            <li class="noInfect">
                <div class="number">${chinaData.chinaTotal.noInfect}</div>
                <div class="item">无症状感染者</div>
                <div class="czhange"><span>昨日</span><b>${chinaData.chinaAdd.noInfect}</b></div>
            </li>
            <li class="importedCase">
                <div class="number">${chinaData.chinaTotal.importedCase}</div>
                <div class="item">境外输入</div>
                <div class="change"><span>昨日</span><b>${chinaData.chinaAdd.importedCase}</b></div>
            </li>
        `;
    $(".brief_body").html(htmlStr)
}

//中国疫情地图
function map() {
    var virusDatas = [
        {name: '香港', value: 1106},
        {name: '内蒙古', value: 235},
        {name: '四川', value: 581},
        {name: '台湾', value: 443},
        {name: '广东', value: 1602},
        {name: '吉林', value: 155},
        {name: '上海', value: 678},
        {name: '山东', value: 792},
        {name: '北京', value: 594},
        {name: '湖北', value: 68135},
        {name: '海南', value: 170},
        {name: '天津', value: 193},
        {name: '陕西', value: 311},
        {name: '山西', value: 198},
        {name: '福建', value: 359},
        {name: '西藏', value: 1},
        {name: '青海', value: 18},
        {name: '澳门', value: 45},
        {name: '宁夏', value: 75},
        {name: '新疆', value: 76},
        {name: '甘肃', value: 139},
        {name: '贵州', value: 147},
        {name: '辽宁', value: 149},
        {name: '云南', value: 185},
        {name: '广西', value: 254},
        {name: '河北', value: 328},
        {name: '重庆', value: 579},
        {name: '江苏', value: 653},
        {name: '江西', value: 932},
        {name: '黑龙江', value: 947},
        {name: '安徽', value: 991},
        {name: '湖南', value: 1019},
        {name: '浙江', value: 1268},
        {name: '河南', value: 1276}
    ];
    //1、初始化echarts图表
    var myChart = echarts.init(document.querySelector(".brief .map_info"))
    //2、设置配置项
    var option = {
        tooltip:{
            formatter:function (param) {
                return param.name + ":" + (param.value?param.value:0)
            }
        },
        visualMap: {
            // 设置映射类型：piecewise分段型、continuous连续性
            type: 'piecewise',
            pieces: [
                { max: 0, label: '0', color: '#fff' },
                { min: 1, max: 10, label: '1-10', color: '#fff7ba' },
                { min: 11, max: 50, label: '11-50', color: '#ffc24b' },
                { min: 51, max: 200, label: '51-200', color: '#ff7c20' },
                { min: 201, max: 1000, label: '201-1000', color: '#fe5e3b' },
                { min: 1001, max: 10000, label: '1000-1万', color: '#e2482b' },
                { min: 10001, label: '1万以上', color: '#b93e26' },
            ],
            itemHeight: 10,
            itemWidth: 10,
            inverse: true,
        },
        series:[{
            data:virusDatas,
            name:'',
            type:'map',
            mapType:'china',
            itemStyle: {
                emphasis: {
                    areaColor: '#c9ffff',
                    label: {
                        show: false
                    }
                }
            },
            // 设置位置：保持地图高宽比的情况下把地图放在容器的正中间
            layoutCenter: ['center', 'center'],
            // 地图缩放
            layoutSize: "100%"
        }]
    };
    myChart.setOption(option);
    $(".brief .map_tab span").eq(0).click(function () {
        virusDatas = [
            {name: '香港', value: 1106},
            {name: '内蒙古', value: 235},
            {name: '四川', value: 581},
            {name: '台湾', value: 443},
            {name: '广东', value: 1602},
            {name: '吉林', value: 155},
            {name: '上海', value: 678},
            {name: '山东', value: 792},
            {name: '北京', value: 594},
            {name: '湖北', value: 68135},
            {name: '海南', value: 170},
            {name: '天津', value: 193},
            {name: '陕西', value: 311},
            {name: '山西', value: 198},
            {name: '福建', value: 359},
            {name: '西藏', value: 1},
            {name: '青海', value: 18},
            {name: '澳门', value: 45},
            {name: '宁夏', value: 75},
            {name: '新疆', value: 76},
            {name: '甘肃', value: 139},
            {name: '贵州', value: 147},
            {name: '辽宁', value: 149},
            {name: '云南', value: 185},
            {name: '广西', value: 254},
            {name: '河北', value: 328},
            {name: '重庆', value: 579},
            {name: '江苏', value: 653},
            {name: '江西', value: 932},
            {name: '黑龙江', value: 947},
            {name: '安徽', value: 991},
            {name: '湖南', value: 1019},
            {name: '浙江', value: 1268},
            {name: '河南', value: 1276}
    ]
        option.series[0].data = virusDatas;
        myChart.setOption(option);
    });
    $(".brief .map_tab span").eq(1).click(function () {
        virusDatas = [
            {name: '香港', value: 53},
            {name: '内蒙古', value: 16},
            {name: '四川', value: 20},
            {name: '台湾', value: 6},
            {name: '广东', value: 9},
            {name: '吉林', value: 0},
            {name: '上海', value: 7},
            {name: '山东', value: 4},
            {name: '北京', value: 2},
            {name: '湖北', value: 0},
            {name: '海南', value: 2},
            {name: '天津', value: 1},
            {name: '陕西', value: 3},
            {name: '山西', value: 0},
            {name: '福建', value: 2},
            {name: '西藏', value: 0},
            {name: '青海', value: 0},
            {name: '澳门', value: 0},
            {name: '宁夏', value: 0},
            {name: '新疆', value: 0},
            {name: '甘肃', value: 0},
            {name: '贵州', value: 0},
            {name: '辽宁', value: 0},
            {name: '云南', value: 0},
            {name: '广西', value: 0},
            {name: '河北', value: 0},
            {name: '重庆', value: 0},
            {name: '江苏', value: 0},
            {name: '江西', value: 0},
            {name: '黑龙江', value: 0},
            {name: '安徽', value: 0}
        ]
        option.series[0].data = virusDatas;
        myChart.setOption(option);
    });

    //切换
    $(".map_tab span").click(function () {
        $(this).addClass("cur").siblings().removeClass("cur");
    });
}

